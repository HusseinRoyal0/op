#Twilio Details

account_sid = 'AC06fdf1b360ac37634c8f403c7bdd335d'
auth_token = 'c75abd50cae337ff24434f4a533395eb'
twilionumber = '+16018846446'
twiliosmsnumber = '+16018846446'

#FC Bot
API_TOKEN = "5856195740:AAFaDbvuIYUfppYSXuG146BJbSiZZ1ACZ4g"

#Host URL
callurl = 'https://e836-196-190-61-63.eu.ngrok.io'
twiliosmsurl = 'https://e836-196-190-61-63.eu.ngrok.io/sms'









